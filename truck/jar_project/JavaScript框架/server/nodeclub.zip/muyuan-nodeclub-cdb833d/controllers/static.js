// static page
exports.about = function(req,res,next){
	res.render('static/about');
};

exports.faq = function(req,res,next){
	res.render('static/faq');
};
