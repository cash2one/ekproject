#!/usr/bin/env sh
env | grep npm | sort | uniq
echo PATH=$PATH
