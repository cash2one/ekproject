Read the following before using the files within this archive.

1. This archive contains files that belong to the source files for the article, Combining animation and ActionScript using Flash Professional CS5 and Flash Builder 4, posted in the Adobe Flash Developer Center:
http://www.adobe.com/devnet/flash/articles/animation_flash_fbuilder.html


Use these files to work along with the tutorial and to explore the completed files.


2. Unpack the archive and put the folder on your desktop.


3. The archive contains the following folders and files:

* project - Place your work in this folder as you complete the tutorial

	- assets: Contains supplied graphics

* project_completed - Compare your work to the completed files in this folder

	- assets: Contains supplied graphics
	- flash: Contains completed files for the Flash section of the tutorial
	- flex: Contains completed files for the Flash Builder section of the tutorial

* project_extras - Contains sample files showing more developed animations