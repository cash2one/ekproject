// PlayFlash.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "PlayFlash.h"
#include "PlayFlashDlg.h"
#include "windows.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlayFlashApp

BEGIN_MESSAGE_MAP(CPlayFlashApp, CWinApp)
	//{{AFX_MSG_MAP(CPlayFlashApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlayFlashApp construction

CPlayFlashApp::CPlayFlashApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPlayFlashApp object

CPlayFlashApp theApp;
HINSTANCE hInst;
typedef int (__stdcall * REGISTERFUNC)(void);

/////////////////////////////////////////////////////////////////////////////
// CPlayFlashApp initialization

LRESULT CALLBACK  mWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return DefWindowProc (hwnd, message, wParam, lParam) ;
}

BOOL CPlayFlashApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

/*ע��shockwave flash object�ؼ����ؼ����ܷ��������ĵ�·����
	TCHAR strCurDrt[500];
	int nLen = ::GetCurrentDirectory(500,strCurDrt);
	if( strCurDrt[nLen]!='\\' )
	{
		strCurDrt[nLen++] = '\\';
		strCurDrt[nLen] = '\0';
	}

	CString strFileName = strCurDrt;
	strFileName +="flash.ocx";
	AfxMessageBox(strFileName);
	hInst = NULL;
	hInst = LoadLibrary( strFileName );
	if( !hInst )
	{
		AfxMessageBox("����flash.ocxʧ�ܣ�����flash.ocx�Ƿ�ͳ�����ͬһĿ¼��");
	}
	else
	{
		
		REGISTERFUNC pRegister;
		pRegister = GetProcAddress((HMODULE)hInst,"DllRegisterServer" );
		(*pRegister)();
	}

	*/
	
	


	/*static TCHAR szAppName[] = TEXT ("HelloWin") ;
     HWND         hwnd ;
     MSG          msg ;
     WNDCLASS     wndclass ;

     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = mWndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = m_hInstance ;
     wndclass.hIcon         = NULL ;
     wndclass.hCursor       = NULL ;
     wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
     wndclass.lpszMenuName  = NULL ;
     wndclass.lpszClassName = szAppName ;

     if (!RegisterClass (&wndclass))
     {
          MessageBox (NULL, TEXT ("This program requires Windows NT!"), 
                      szAppName, MB_ICONERROR) ;
          return 0 ;
     }
	hwnd = CreateWindow (szAppName,                  // window class name
                          TEXT ("The Hello Program"), // window caption
                          WS_OVERLAPPEDWINDOW,        // window style
                          CW_USEDEFAULT,              // initial x position
                          CW_USEDEFAULT,              // initial y position
                          CW_USEDEFAULT,              // initial x size
                          CW_USEDEFAULT,              // initial y size
                          NULL,                       // parent window handle
                          NULL,                       // window menu handle
                          m_hInstance,                  // program instance handle
                          NULL) ;                     // creation parameters
     
     ShowWindow(hwnd,1) ;
     UpdateWindow (hwnd) ;*/
     

	 	CPlayFlashDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	
	
	return FALSE;
}


