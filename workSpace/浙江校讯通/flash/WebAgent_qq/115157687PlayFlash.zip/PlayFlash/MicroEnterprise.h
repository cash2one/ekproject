#if !defined(AFX_MICROENTERPRISE_H__D27A2378_5C95_4B0D_A559_11524E3093EE__INCLUDED_)
#define AFX_MICROENTERPRISE_H__D27A2378_5C95_4B0D_A559_11524E3093EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MicroEnterprise.h : header file
//

#include "shockwaveflash.h"

/////////////////////////////////////////////////////////////////////////////
// CMicroEnterprise window

class CMicroEnterprise : public CWnd
{
// Construction
public:
	CMicroEnterprise();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMicroEnterprise)
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL Create(CWnd* pParentWnd /*= NULL*/);
	virtual ~CMicroEnterprise();
	CShockwaveFlash	m_FlashPlayer;
	// Generated message map functions
protected:
	//{{AFX_MSG(CMicroEnterprise)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MICROENTERPRISE_H__D27A2378_5C95_4B0D_A559_11524E3093EE__INCLUDED_)
