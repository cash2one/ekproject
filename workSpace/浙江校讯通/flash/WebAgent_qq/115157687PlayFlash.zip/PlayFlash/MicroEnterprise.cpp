// MicroEnterprise.cpp : implementation file
//

#include "stdafx.h"
#include "PlayFlash.h"
#include "MicroEnterprise.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMicroEnterprise
#define WS_EX_LAYERED 0x80000
#define LWA_COLORKEY 0x1
CMicroEnterprise::CMicroEnterprise()
{
}

CMicroEnterprise::~CMicroEnterprise()
{
}


BEGIN_MESSAGE_MAP(CMicroEnterprise, CWnd)
	//{{AFX_MSG_MAP(CMicroEnterprise)
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMicroEnterprise message handlers

BOOL CMicroEnterprise::Create(CWnd* pParentWnd /*= NULL*/)
{
	// Register a custom WndClass and create a window.
	// This must be done because CBounceWnd has a custom cursor, and
	//  no icon.
	LPCTSTR lpszBounceClass =
		AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS ,
			LoadCursor(NULL, IDC_CROSS),
			(HBRUSH)(COLOR_WINDOW+1),
			NULL);
	 return CreateEx(WS_EX_TOPMOST | WS_EX_LAYERED,lpszBounceClass,
              NULL, WS_POPUP | WS_VISIBLE | WS_CLIPSIBLINGS | WS_OVERLAPPED, 
			  100, 100, 180, 180, pParentWnd->GetSafeHwnd(), NULL);
	
}




int CMicroEnterprise::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	//CWnd::SetDialogBkColor(RGB(200,200,200));
	// TODO: Add your specialized creation code here
	CRect rc;
	this->GetClientRect(&rc);
	CRect frect;
	m_FlashPlayer.Create("",
		WS_CHILDWINDOW | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_OVERLAPPED,
		rc,this,500);

	HWND hWnd = m_FlashPlayer.Detach();
	m_FlashPlayer.SubclassWindow(hWnd);
		/*m_FlashPlayer.GetWindowRect(&frect);

	rc.bottom = frect.bottom;
	rc.right = frect.right;

	m_FlashPlayer.MoveWindow(&frect, true );*/


	TCHAR strCurDrt[500];
	int nLen = ::GetCurrentDirectory(500,strCurDrt);
	if( strCurDrt[nLen]!='\\' )
	{
		strCurDrt[nLen++] = '\\';
		strCurDrt[nLen] = '\0';
	}
	
	rc.left +=10;
	m_FlashPlayer.MoveWindow(&rc, true );
	m_FlashPlayer.ShowWindow(SW_SHOW);
	
	CString strFileName = strCurDrt;
	strFileName += "1023140141.swf";
	m_FlashPlayer.LoadMovie(0, strFileName);
	m_FlashPlayer.SetBGColor("#C8C8C8");
	m_FlashPlayer.SetLoop(FALSE);
	m_FlashPlayer.SetWMode("Transparent");	

	m_FlashPlayer.SetScaleMode(3);
	m_FlashPlayer.Play();
	
	//m_FlashPlayer.SetMenu(false);
/*
	
	//MoveWindow( &frect, true );

	CDC *pDC=m_FlashPlayer.GetDC();

	//CDC *pDC = AfxGetMainWnd()->GetDC();
	//COLORREF  m_clr = RGB(255,0,0);
	
	//;
*/
	//if(GetSafeHwnd()!=hWnd)return 0;
	COLORREF  m_clrMask = RGB(200,200,200);
	//SetWindowLong(GetSafeHwnd(), GWL_EXSTYLE, GetWindowLong(GetSafeHwnd(), GWL_EXSTYLE)|WS_EX_LAYERED); 
	typedef int (WINAPI* LPFUNC)(HWND, COLORREF , BYTE, DWORD);
	//typedef  BOOL (WINAPI*UPFUNC)(HWND,HDC,POINT*,SIZE*,HDC,POINT*,COLORREF,BLENDFUNCTION*,DWORD);  
	HINSTANCE hins = ::LoadLibrary("User32.DLL");
	if(hins){		
		LPFUNC func2 = (LPFUNC)GetProcAddress(hins,"SetLayeredWindowAttributes");
		if(func2)
		{
			
			func2(GetSafeHwnd(), m_clrMask, 0, LWA_COLORKEY);
		}
		
		FreeLibrary(hins);
	} 

	
	return 0;
}

void CMicroEnterprise::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	PostMessage(WM_NCLBUTTONDOWN,HTCAPTION,MAKELPARAM(point.x,point.y));
	CWnd::OnLButtonDown(nFlags, point);
}


